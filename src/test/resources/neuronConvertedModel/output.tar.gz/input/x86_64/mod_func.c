#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern void _AMPA_syn_reg(void);
extern void _AMPA_syn_inh_reg(void);
extern void _BackgroundRandomIClamps_reg(void);
extern void _Ca_conc_reg(void);
extern void _Ca_pyr_reg(void);
extern void _GABA_syn_reg(void);
extern void _GABA_syn_inh_reg(void);
extern void _Kahp_pyr_reg(void);
extern void _Kdr_bask_reg(void);
extern void _Kdr_pyr_reg(void);
extern void _LeakConductance_bask_reg(void);
extern void _LeakConductance_pyr_reg(void);
extern void _Na_bask_reg(void);
extern void _Na_pyr_reg(void);

void modl_reg(){
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");

    fprintf(stderr," mod_nsgportal/AMPA_syn.mod");
    fprintf(stderr," mod_nsgportal/AMPA_syn_inh.mod");
    fprintf(stderr," mod_nsgportal/BackgroundRandomIClamps.mod");
    fprintf(stderr," mod_nsgportal/Ca_conc.mod");
    fprintf(stderr," mod_nsgportal/Ca_pyr.mod");
    fprintf(stderr," mod_nsgportal/GABA_syn.mod");
    fprintf(stderr," mod_nsgportal/GABA_syn_inh.mod");
    fprintf(stderr," mod_nsgportal/Kahp_pyr.mod");
    fprintf(stderr," mod_nsgportal/Kdr_bask.mod");
    fprintf(stderr," mod_nsgportal/Kdr_pyr.mod");
    fprintf(stderr," mod_nsgportal/LeakConductance_bask.mod");
    fprintf(stderr," mod_nsgportal/LeakConductance_pyr.mod");
    fprintf(stderr," mod_nsgportal/Na_bask.mod");
    fprintf(stderr," mod_nsgportal/Na_pyr.mod");
    fprintf(stderr, "\n");
  }
  _AMPA_syn_reg();
  _AMPA_syn_inh_reg();
  _BackgroundRandomIClamps_reg();
  _Ca_conc_reg();
  _Ca_pyr_reg();
  _GABA_syn_reg();
  _GABA_syn_inh_reg();
  _Kahp_pyr_reg();
  _Kdr_bask_reg();
  _Kdr_pyr_reg();
  _LeakConductance_bask_reg();
  _LeakConductance_pyr_reg();
  _Na_bask_reg();
  _Na_pyr_reg();
}
